from fastapi import FastAPI, BackgroundTasks
from pydantic import BaseModel
import uvicorn
from builder_core import deploy_app

app = FastAPI(title="Vibe Hosting API")

class DeployRequest(BaseModel):
    repo_url: str
    app_name: str
    app_domain: str

@app.post("/api/deploy")
async def trigger_deploy(req: DeployRequest, background_tasks: BackgroundTasks):
    # Đưa tác vụ deploy vào chạy ngầm (Background Task) để không chặn API
    background_tasks.add_task(deploy_app, req.repo_url, req.app_name, req.app_domain)
    return {
        "status": "success", 
        "message": f"Đã đưa yêu cầu triển khai {req.app_name} vào hàng đợi.",
        "app_url": f"https://{req.app_domain}"
    }

@app.get("/api/health")
async def health_check():
    return {"status": "ok", "service": "Vibe Hosting API is running"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)
